# pypisca

#### pypisca
<br>

[![CodeQL](https://github.com/r3mkumar/pypisca/actions/workflows/github-code-scanning/codeql/badge.svg)](https://github.com/r3mkumar/pypisca/actions/workflows/github-code-scanning/codeql)
[![Upload Python Package](https://github.com/r3mkumar/pypisca/actions/workflows/python-publish.yml/badge.svg)](https://github.com/r3mkumar/pypisca/actions/workflows/python-publish.yml)
